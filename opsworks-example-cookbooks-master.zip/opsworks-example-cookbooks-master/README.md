AWS OpsWorks Example Cookbooks
==============================

The *app example cookbooks are used with the AWS OpsWorks [Getting Started Walkthroughs](http://docs.aws.amazon.com/opsworks/latest/userguide/walkthroughs.html).
