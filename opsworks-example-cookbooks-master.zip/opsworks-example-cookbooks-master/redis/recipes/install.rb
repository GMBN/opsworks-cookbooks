Chef::Log.info('Hello from Redis')
